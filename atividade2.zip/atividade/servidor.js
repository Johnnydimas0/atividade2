var http = require('http')


http.createServer().listen(8080)

console.log("servidor criado")

