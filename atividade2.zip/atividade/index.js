const express = require('express')

const app = express()


app.get("/principal", function(res, resp){
    resp.sendFile(__dirname +"/index.html")
})

app.get("/QuizBancodeDados", function(res, resp){
    resp.sendFile(__dirname +"/BancodeDados")
})

app.get("/POO", function(res, resp){
    resp.sendFile(__dirname +"/POO")
})

app.get("/HtmlCssJAvaScript", function(res, resp){
    resp.sendFile(__dirname +"/Web")
})


app.listen(8080, function(){
    console.log("Servidor Express")
})

